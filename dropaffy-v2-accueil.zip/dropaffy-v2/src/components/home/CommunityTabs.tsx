import type { CommunityCategory } from "../../types/community";

export const COMMUNITY_TABS: { id: CommunityCategory; label: string }[] = [
  { id: "offres", label: "Offres" },
  { id: "recherches", label: "Recherches" },
];

interface CommunityTabsProps {
  active: CommunityCategory;
  onChange: (category: CommunityCategory) => void;
}

export default function CommunityTabs({ active, onChange }: CommunityTabsProps) {
  return (
    <div className="tabs" role="tablist" aria-label="Catégories de la communauté">
      {COMMUNITY_TABS.map((tab) => (
        <button
          key={tab.id}
          id={`tab-${tab.id}`}
          type="button"
          role="tab"
          aria-selected={active === tab.id}
          aria-controls={`panel-${tab.id}`}
          className={`tab${active === tab.id ? " is-active" : ""}`}
          onClick={() => onChange(tab.id)}
        >
          {tab.label}
        </button>
      ))}
    </div>
  );
}
