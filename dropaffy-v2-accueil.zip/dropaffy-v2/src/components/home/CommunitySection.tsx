import { useState } from "react";
import { useCommunityPosts } from "../../hooks/useCommunityPosts";
import type { CommunityCategory } from "../../types/community";
import CommunityTabs from "./CommunityTabs";
import PostCard from "./PostCard";
import { EmptyState, ErrorState, LoadingState } from "./CommunityStates";

export default function CommunitySection() {
  const [category, setCategory] = useState<CommunityCategory>("offres");
  const { posts, status, retry } = useCommunityPosts(category);

  return (
    <section className="community" aria-labelledby="community-title">
      <h2 id="community-title">Communauté</h2>
      <CommunityTabs active={category} onChange={setCategory} />

      <div
        id={`panel-${category}`}
        role="tabpanel"
        aria-labelledby={`tab-${category}`}
        className="community-panel"
      >
        {status === "loading" && <LoadingState />}
        {status === "error" && <ErrorState onRetry={retry} />}
        {status === "success" && posts.length === 0 && <EmptyState />}
        {status === "success" && posts.length > 0 && (
          <div className="post-list">
            {posts.map((post) => (
              <PostCard key={post.id} post={post} />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
