export function LoadingState() {
  return (
    <div className="state-box" role="status" aria-live="polite" aria-label="Chargement">
      <div className="skeleton" />
      <div className="skeleton" />
      <div className="skeleton short" />
    </div>
  );
}

export function EmptyState() {
  return (
    <div className="state-box state-center">
      <p>Les premières publications apparaîtront ici.</p>
    </div>
  );
}

export function ErrorState({ onRetry }: { onRetry: () => void }) {
  return (
    <div className="state-box state-center" role="alert">
      <p>Impossible de charger les publications. Vérifiez votre connexion et réessayez.</p>
      <button type="button" className="btn btn-secondary btn-small" onClick={onRetry}>
        Réessayer
      </button>
    </div>
  );
}
