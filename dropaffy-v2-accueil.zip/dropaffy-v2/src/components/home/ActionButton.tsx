import type { ReactNode } from "react";
import { Link } from "react-router-dom";
import { isRouteAvailable } from "../../config/routes";

interface ActionButtonProps {
  to: string;
  variant: "primary" | "secondary";
  children: ReactNode;
}

/**
 * Bouton de navigation prêt pour l'intégration future :
 * tant que la page cible n'existe pas, il reste inactif.
 */
export default function ActionButton({ to, variant, children }: ActionButtonProps) {
  const className = `btn btn-${variant}`;

  if (isRouteAvailable(to)) {
    return (
      <Link to={to} className={className}>
        {children}
      </Link>
    );
  }

  return (
    <button
      type="button"
      className={`${className} is-pending`}
      aria-disabled="true"
      title="Bientôt disponible"
      onClick={(e) => e.preventDefault()}
    >
      {children}
    </button>
  );
}
