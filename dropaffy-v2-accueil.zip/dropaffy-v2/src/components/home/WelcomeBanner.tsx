interface WelcomeBannerProps {
  /** Prénom du membre. Sera fourni plus tard par l'authentification. */
  firstName?: string;
}

export default function WelcomeBanner({ firstName }: WelcomeBannerProps) {
  const name = firstName?.trim();
  return (
    <p className="welcome">
      Bonjour{name ? ` ${name}` : ""}, bienvenue sur DropAffy
    </p>
  );
}
