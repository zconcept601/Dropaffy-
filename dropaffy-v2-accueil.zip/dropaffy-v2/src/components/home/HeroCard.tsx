import { ROUTES } from "../../config/routes";
import ActionButton from "./ActionButton";

export default function HeroCard() {
  return (
    <section className="hero" aria-labelledby="hero-title">
      <h1 id="hero-title">Votre réseau commence ici.</h1>
      <p>
        Découvrez des opportunités, partagez vos besoins et développez vos
        relations professionnelles.
      </p>
      <div className="hero-actions">
        <ActionButton to={`${ROUTES.publish}?type=offre`} variant="primary">
          Publier une offre
        </ActionButton>
        <ActionButton to={`${ROUTES.publish}?type=besoin`} variant="secondary">
          Exprimer un besoin
        </ActionButton>
      </div>
    </section>
  );
}
