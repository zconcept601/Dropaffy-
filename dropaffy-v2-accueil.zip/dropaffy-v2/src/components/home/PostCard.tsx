import type { CommunityPost } from "../../types/community";

export default function PostCard({ post }: { post: CommunityPost }) {
  const date = new Date(post.createdAt);
  const dateLabel = Number.isNaN(date.getTime())
    ? ""
    : date.toLocaleDateString("fr-FR", { day: "numeric", month: "short" });

  return (
    <article className="post-card">
      <h3>{post.title}</h3>
      <p>{post.description}</p>
      <footer>
        <span>{post.authorName}</span>
        {post.location && <span>{post.location}</span>}
        {dateLabel && <span>{dateLabel}</span>}
      </footer>
    </article>
  );
}
