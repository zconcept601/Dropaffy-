import { NavLink } from "react-router-dom";
import { NAV_ITEMS } from "../../config/navigation";
import { isRouteAvailable } from "../../config/routes";

export default function BottomNav() {
  return (
    <nav className="bottom-nav" aria-label="Navigation principale">
      <ul>
        {NAV_ITEMS.map(({ id, label, path, icon: Icon }) => (
          <li key={id}>
            {isRouteAvailable(path) ? (
              <NavLink
                to={path}
                end
                className={({ isActive }) => `nav-item${isActive ? " is-active" : ""}`}
              >
                <Icon size={22} aria-hidden="true" />
                <span>{label}</span>
              </NavLink>
            ) : (
              <button
                type="button"
                className="nav-item is-pending"
                aria-disabled="true"
                title="Bientôt disponible"
                onClick={(e) => e.preventDefault()}
              >
                <Icon size={22} aria-hidden="true" />
                <span>{label}</span>
              </button>
            )}
          </li>
        ))}
      </ul>
    </nav>
  );
}
