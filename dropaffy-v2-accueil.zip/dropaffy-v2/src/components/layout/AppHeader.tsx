import type { ReactNode } from "react";
import { Bell, MessageCircle } from "lucide-react";
import { HEADER_OPTIONS } from "../../config/navigation";

/**
 * Les icônes ne sont pas encore reliées à une fonctionnalité réelle :
 * elles sont affichées comme indisponibles (aria-disabled), sans action.
 */
function PendingIconButton({ label, children }: { label: string; children: ReactNode }) {
  return (
    <button
      type="button"
      className="icon-btn is-pending"
      aria-label={`${label} (bientôt disponible)`}
      aria-disabled="true"
      title="Bientôt disponible"
      onClick={(e) => e.preventDefault()}
    >
      {children}
    </button>
  );
}

export default function AppHeader() {
  return (
    <header className="app-header">
      <div className="brand" aria-label="DropAffy">
        <span className="brand-mark" aria-hidden="true">D</span>
        <span className="brand-name">DropAffy</span>
      </div>
      <div className="header-actions">
        {HEADER_OPTIONS.showMessages && (
          <PendingIconButton label="Messages">
            <MessageCircle size={22} />
          </PendingIconButton>
        )}
        <PendingIconButton label="Notifications">
          <Bell size={22} />
        </PendingIconButton>
      </div>
    </header>
  );
}
