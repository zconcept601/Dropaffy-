export type CommunityCategory = "offres" | "recherches";

export interface CommunityPost {
  id: string;
  category: CommunityCategory;
  title: string;
  description: string;
  authorName: string;
  location?: string;
  createdAt: string; // date ISO
}

export type LoadStatus = "loading" | "success" | "error";
