import AppHeader from "../components/layout/AppHeader";
import WelcomeBanner from "../components/home/WelcomeBanner";
import HeroCard from "../components/home/HeroCard";
import CommunitySection from "../components/home/CommunitySection";

export default function HomePage() {
  // Le prénom viendra de l'authentification dans une prochaine étape.
  const firstName: string | undefined = undefined;

  return (
    <>
      <AppHeader />
      <main className="page">
        <WelcomeBanner firstName={firstName} />
        <HeroCard />
        <CommunitySection />
      </main>
    </>
  );
}
