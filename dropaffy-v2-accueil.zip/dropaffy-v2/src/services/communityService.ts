import type { CommunityCategory, CommunityPost } from "../types/community";

/**
 * Point d'entrée unique pour récupérer les publications de la communauté.
 *
 * Aucune source de données n'est branchée à cette étape (pas de Supabase,
 * pas de fausses publications). La fonction renvoie donc une liste vide.
 * Lors de la connexion réelle, seul ce fichier devra être modifié.
 */
export async function fetchCommunityPosts(
  _category: CommunityCategory,
): Promise<CommunityPost[]> {
  return [];
}
