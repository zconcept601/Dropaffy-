import { useCallback, useEffect, useState } from "react";
import { fetchCommunityPosts } from "../services/communityService";
import type { CommunityCategory, CommunityPost, LoadStatus } from "../types/community";

export function useCommunityPosts(category: CommunityCategory) {
  const [posts, setPosts] = useState<CommunityPost[]>([]);
  const [status, setStatus] = useState<LoadStatus>("loading");
  const [attempt, setAttempt] = useState(0);

  useEffect(() => {
    let cancelled = false;
    setStatus("loading");

    fetchCommunityPosts(category)
      .then((result) => {
        if (cancelled) return;
        setPosts(result);
        setStatus("success");
      })
      .catch(() => {
        if (cancelled) return;
        setPosts([]);
        setStatus("error");
      });

    return () => {
      cancelled = true;
    };
  }, [category, attempt]);

  const retry = useCallback(() => setAttempt((n) => n + 1), []);

  return { posts, status, retry };
}
