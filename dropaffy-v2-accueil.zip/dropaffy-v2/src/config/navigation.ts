import { Activity, Home, PlusCircle, User, Users, type LucideIcon } from "lucide-react";
import { ROUTES } from "./routes";

export interface NavItem {
  id: string;
  label: string;
  path: string;
  icon: LucideIcon;
}

export const NAV_ITEMS: NavItem[] = [
  { id: "home", label: "Accueil", path: ROUTES.home, icon: Home },
  { id: "publish", label: "Publier", path: ROUTES.publish, icon: PlusCircle },
  { id: "contacts", label: "Contacts", path: ROUTES.contacts, icon: Users },
  { id: "activity", label: "Activité", path: ROUTES.activity, icon: Activity },
  { id: "profile", label: "Profil", path: ROUTES.profile, icon: User },
];

/** Icône de messages : masquée tant qu'elle n'est pas prévue dans la structure. */
export const HEADER_OPTIONS = {
  showMessages: false,
} as const;
