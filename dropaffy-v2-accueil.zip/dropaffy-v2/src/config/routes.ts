/**
 * Chemins de l'application.
 * Seules les pages listées dans AVAILABLE_ROUTES existent réellement.
 * Quand une page est livrée et validée, ajoutez simplement son chemin ici :
 * la navigation et les boutons s'activent automatiquement.
 */
export const ROUTES = {
  home: "/",
  publish: "/publier",
  contacts: "/contacts",
  activity: "/activite",
  profile: "/profil",
} as const;

export const AVAILABLE_ROUTES: ReadonlySet<string> = new Set([ROUTES.home]);

export function isRouteAvailable(path: string): boolean {
  const pathname = path.split("?")[0];
  return AVAILABLE_ROUTES.has(pathname);
}
